package com.alidinler.ezanvakti;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;

/** Ayarlar ve ezan ses dosyaları. Telefon yeniden açılıp kilidi açılmadan
 *  önce de okunabilsin diye "cihaz korumalı" depolamada tutulur. */
public final class Prefs {
    public static final String[] VAKIT = {"Sabah", "Öğle", "İkindi", "Akşam", "Yatsı"};
    // Ezan vakit sırası -> PrayerTimes dizisindeki yeri (güneş atlanır)
    public static final int[] TIME_INDEX = {0, 2, 3, 4, 5};

    static Context dp(Context c) { return c.createDeviceProtectedStorageContext(); }

    static SharedPreferences sp(Context c) {
        return dp(c).getSharedPreferences("ezan", Context.MODE_PRIVATE);
    }

    public static boolean enabled(Context c, int v) { return sp(c).getBoolean("on_" + v, true); }
    public static void setEnabled(Context c, int v, boolean b) { sp(c).edit().putBoolean("on_" + v, b).apply(); }

    public static int adj(Context c, int v) { return sp(c).getInt("adj_" + v, 0); }
    public static void setAdj(Context c, int v, int m) { sp(c).edit().putInt("adj_" + v, m).apply(); }

    public static int volume(Context c) { return sp(c).getInt("volume", 100); }
    public static void setVolume(Context c, int v) { sp(c).edit().putInt("volume", v).apply(); }

    public static String soundName(Context c, String key) { return sp(c).getString("name_" + key, null); }
    public static void setSoundName(Context c, String key, String n) { sp(c).edit().putString("name_" + key, n).apply(); }

    /** key: "genel" veya "sabah" */
    public static File soundFile(Context c, String key) {
        return new File(dp(c).getFilesDir(), "ezan_" + key);
    }

    static boolean has(File f) { return f.exists() && f.length() > 0; }

    /** Bu vakitte çalınacak dosya; seçilmemişse null (telefonun alarm sesi çalar). */
    public static File fileForVakit(Context c, int v) {
        if (v == 0) {
            File s = soundFile(c, "sabah");
            if (has(s)) return s;
        }
        File g = soundFile(c, "genel");
        return has(g) ? g : null;
    }
}
