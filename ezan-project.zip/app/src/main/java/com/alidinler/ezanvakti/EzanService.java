package com.alidinler.ezanvakti;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.io.File;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

/** Ezanı alarm ses kanalından (sessiz modda da duyulur) çalan ön plan servisi. */
public class EzanService extends Service {
    public static final String ACTION_STOP = "com.alidinler.ezanvakti.STOP";
    private static final String CH = "ezan_calan";

    private MediaPlayer mp;
    private AudioManager am;
    private AudioFocusRequest focus;
    private int savedVolume = -1;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable timeout = this::stopAll;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        int v = intent != null ? intent.getIntExtra("vakit", 1) : 1;
        boolean test = intent != null && intent.getBooleanExtra("test", false);
        Notification n = buildNotification(v, test);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(1, n);
            }
        } catch (Exception e) {
            AlarmReceiver.fallbackNotify(this, v);
            stopSelf();
            return START_NOT_STICKY;
        }
        releasePlayer();
        play(v);
        return START_NOT_STICKY;
    }

    private Notification buildNotification(int v, boolean test) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CH, "Ezan okunuyor", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.setBypassDnd(true);
        nm.createNotificationChannel(ch);

        PendingIntent stop = PendingIntent.getService(this, 200,
                new Intent(this, EzanService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 201,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String time = DateTimeFormatter.ofPattern("HH:mm").withZone(PrayerTimes.ZONE).format(Instant.now());
        return new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle((test ? "Deneme: " : "") + Prefs.VAKIT[v] + " ezanı okunuyor")
                .setContentText("Ankara • " + time)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setContentIntent(open)
                .setDeleteIntent(stop)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_notif), "Durdur", stop).build())
                .build();
    }

    private void play(int v) {
        am = getSystemService(AudioManager.class);
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        // Alarm ses seviyesini ayarlanan düzeye getir (bitince eski haline döner)
        try {
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            savedVolume = am.getStreamVolume(AudioManager.STREAM_ALARM);
            int target = Math.max(1, Math.round(max * Prefs.volume(this) / 100f));
            am.setStreamVolume(AudioManager.STREAM_ALARM, target, 0);
        } catch (Exception e) {
            savedVolume = -1;
        }
        try {
            focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(aa).build();
            am.requestAudioFocus(focus);
        } catch (Exception ignored) { }

        File f = Prefs.fileForVakit(this, v);
        boolean ok = false;
        if (f != null) ok = start(aa, f, null, false);
        if (!ok) {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            ok = start(aa, null, u, true);
            if (!ok) ok = start(aa, null, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE), true);
            h.postDelayed(timeout, 60 * 1000L); // ezan dosyası yoksa alarm sesi 1 dk çalar
        }
        if (!ok) { stopAll(); return; }
        h.postDelayed(timeout, 8 * 60 * 1000L); // güvenlik: en fazla 8 dakika
    }

    private boolean start(AudioAttributes aa, File f, Uri u, boolean loop) {
        try {
            releasePlayer();
            mp = new MediaPlayer();
            mp.setAudioAttributes(aa);
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            if (f != null) mp.setDataSource(f.getPath()); else mp.setDataSource(this, u);
            mp.setLooping(loop);
            mp.setOnCompletionListener(x -> stopAll());
            mp.setOnErrorListener((x, w, e) -> { stopAll(); return true; });
            mp.prepare();
            mp.start();
            return true;
        } catch (Exception e) {
            releasePlayer();
            return false;
        }
    }

    private void releasePlayer() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
            mp = null;
        }
    }

    private void stopAll() {
        h.removeCallbacks(timeout);
        releasePlayer();
        if (am != null) {
            if (savedVolume >= 0) {
                try { am.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0); } catch (Exception ignored) { }
                savedVolume = -1;
            }
            if (focus != null) {
                try { am.abandonAudioFocusRequest(focus); } catch (Exception ignored) { }
                focus = null;
            }
        }
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(timeout);
        releasePlayer();
        super.onDestroy();
    }
}
