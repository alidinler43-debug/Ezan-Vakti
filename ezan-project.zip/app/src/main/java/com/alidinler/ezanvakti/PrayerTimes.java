package com.alidinler.ezanvakti;

import java.time.LocalDate;
import java.time.ZoneId;

/**
 * Ankara için namaz vakitlerini internet gerekmeden hesaplar.
 * Diyanet (Türkiye) yöntemi: imsak 18°, yatsı 17°, ikindi asr-ı evvel,
 * temkinler: güneş -7, öğle +5, ikindi +4, akşam +7 dakika.
 */
public final class PrayerTimes {
    public static final double LAT = 39.9208;
    public static final double LNG = 32.8541;
    public static final ZoneId ZONE = ZoneId.of("Europe/Istanbul");

    // Dönen dizi: gece yarısından itibaren dakika olarak
    // [0] imsak, [1] güneş, [2] öğle, [3] ikindi, [4] akşam, [5] yatsı
    public static int[] minutesFor(LocalDate d) {
        double tz = d.atStartOfDay(ZONE).getOffset().getTotalSeconds() / 3600.0;
        double jd = julian(d.getYear(), d.getMonthValue(), d.getDayOfMonth()) - LNG / (15.0 * 24.0);

        double[] t = {5, 6, 12, 13, 18, 18};
        for (int iter = 0; iter < 3; iter++) {
            double[] p = new double[6];
            for (int i = 0; i < 6; i++) p[i] = t[i] / 24.0;
            t = new double[]{
                    sunAngleTime(jd, 18.0, p[0], true),
                    sunAngleTime(jd, 0.833, p[1], true),
                    midDay(jd, p[2]),
                    asrTime(jd, 1.0, p[3]),
                    sunAngleTime(jd, 0.833, p[4], false),
                    sunAngleTime(jd, 17.0, p[5], false)
            };
        }
        int[] adj = {0, -7, 5, 4, 7, 0};
        int[] out = new int[6];
        for (int i = 0; i < 6; i++) {
            double h = t[i] + tz - LNG / 15.0;
            out[i] = (int) Math.round(h * 60.0) + adj[i];
        }
        return out;
    }

    private static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        double a = Math.floor(y / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
    }

    // [0] sapma (declination), [1] zaman denklemi (saat)
    private static double[] sunPosition(double jd) {
        double D = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * D);
        double q = fixAngle(280.459 + 0.98564736 * D);
        double L = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g));
        double e = 23.439 - 0.00000036 * D;
        double ra = fixHour(datan2(dcos(e) * dsin(L), dcos(L)) / 15.0);
        double eqt = q / 15.0 - ra;
        double decl = dasin(dsin(e) * dsin(L));
        return new double[]{decl, eqt};
    }

    private static double midDay(double jd, double t) {
        double eqt = sunPosition(jd + t)[1];
        return fixHour(12 - eqt);
    }

    private static double sunAngleTime(double jd, double angle, double t, boolean beforeNoon) {
        double decl = sunPosition(jd + t)[0];
        double noon = midDay(jd, t);
        double x = (-dsin(angle) - dsin(decl) * dsin(LAT)) / (dcos(decl) * dcos(LAT));
        x = Math.max(-1, Math.min(1, x));
        double T = dacos(x) / 15.0;
        return noon + (beforeNoon ? -T : T);
    }

    private static double asrTime(double jd, double factor, double t) {
        double decl = sunPosition(jd + t)[0];
        double angle = -darccot(factor + dtan(Math.abs(LAT - decl)));
        return sunAngleTime(jd, angle, t, false);
    }

    private static double dsin(double d) { return Math.sin(Math.toRadians(d)); }
    private static double dcos(double d) { return Math.cos(Math.toRadians(d)); }
    private static double dtan(double d) { return Math.tan(Math.toRadians(d)); }
    private static double dasin(double x) { return Math.toDegrees(Math.asin(x)); }
    private static double dacos(double x) { return Math.toDegrees(Math.acos(x)); }
    private static double datan2(double y, double x) { return Math.toDegrees(Math.atan2(y, x)); }
    private static double darccot(double x) { return Math.toDegrees(Math.atan(1.0 / x)); }
    private static double fixAngle(double a) { a = a - 360.0 * Math.floor(a / 360.0); return a < 0 ? a + 360 : a; }
    private static double fixHour(double a) { a = a - 24.0 * Math.floor(a / 24.0); return a < 0 ? a + 24 : a; }
}
