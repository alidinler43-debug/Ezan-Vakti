package com.alidinler.ezanvakti;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.time.LocalDate;

/** Bir sonraki ezan vaktini, Android'in en güçlü alarm türüyle (çalar saat alarmı) kurar. */
public final class Scheduler {
    public static final String ACTION_EZAN = "com.alidinler.ezanvakti.EZAN";

    public static final class Next {
        public final int vakit;
        public final long millis;
        Next(int v, long m) { vakit = v; millis = m; }
    }

    public static long vakitMillis(Context c, LocalDate d, int v, int[] times) {
        int minutes = times[Prefs.TIME_INDEX[v]] + Prefs.adj(c, v);
        return d.atStartOfDay(PrayerTimes.ZONE).plusMinutes(minutes).toInstant().toEpochMilli();
    }

    public static Next findNext(Context c, long after) {
        LocalDate today = LocalDate.now(PrayerTimes.ZONE);
        Next best = null;
        for (int off = -1; off <= 3; off++) {
            LocalDate d = today.plusDays(off);
            int[] t = PrayerTimes.minutesFor(d);
            for (int v = 0; v < 5; v++) {
                if (!Prefs.enabled(c, v)) continue;
                long ms = vakitMillis(c, d, v, t);
                if (ms > after && (best == null || ms < best.millis)) best = new Next(v, ms);
            }
        }
        return best;
    }

    public static void scheduleNext(Context c) {
        scheduleNextAfter(c, System.currentTimeMillis());
    }

    public static void scheduleNextAfter(Context c, long after) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACTION_EZAN);
        Next n = findNext(c, after);
        if (n == null) {
            PendingIntent old = PendingIntent.getBroadcast(c, 100, i,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (old != null) am.cancel(old);
            return;
        }
        i.putExtra("vakit", n.vakit).putExtra("time", n.millis);
        PendingIntent op = PendingIntent.getBroadcast(c, 100, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent show = PendingIntent.getActivity(c, 101, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(n.millis, show), op);
                return;
            }
        } catch (SecurityException ignored) { }
        // İzin yoksa yedek: yine de uyku modunda çalışan (ama dakikası kayabilen) alarm
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, n.millis, op);
    }

    public static boolean exactAllowed(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am.canScheduleExactAlarms();
    }
}
