package com.alidinler.ezanvakti;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_GENEL = 11, REQ_SABAH = 12;
    private static final int BG = 0xFF0B2E28, CARD = 0xFF134A40, GOLD = 0xFFE8C468,
            TXT = 0xFFF2F2F2, SUB = 0xFFB8D4CC, OK = 0xFF7EE07E, WARN = 0xFFFFB25A, BTN = 0xFF1E6B5C;

    private LinearLayout root;
    private TextView nextTv;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() { updateNext(); h.postDelayed(this, 20000); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        root.setPadding(p, p, p, p);
        sv.addView(root);
        sv.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(),
                    ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(sv);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Scheduler.scheduleNext(this);
        build();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] g) { build(); }

    // ---------------------------------------------------------------- ekran
    private void build() {
        root.removeAllViews();
        LocalDate today = LocalDate.now(PrayerTimes.ZONE);

        TextView title = tv("🕌 Ezan Vakti • Ankara", 24, GOLD, true);
        root.addView(title);
        root.addView(tv(today.format(DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", new Locale("tr"))), 15, SUB, false));

        LinearLayout nc = card();
        nextTv = tv("", 18, TXT, true);
        nc.addView(nextTv);
        root.addView(nc);
        updateNext();

        // ---- Vakitler
        LinearLayout tc = card();
        tc.addView(tv("Bugünün vakitleri", 17, GOLD, true));
        int[] m = PrayerTimes.minutesFor(today);
        String[] names = {"İmsak (Sabah)", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı"};
        for (int i = 0; i < 6; i++) {
            final int v = i == 0 ? 0 : i - 1;
            boolean ezanli = i != 1;
            int adj = ezanli ? Prefs.adj(this, v) : 0;
            LinearLayout row = hrow();
            TextView n = tv(names[i], 17, TXT, false);
            row.addView(n, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(tv(hhmm(m[i] + adj), 20, TXT, true));
            if (ezanli) {
                Switch sw = new Switch(this);
                sw.setChecked(Prefs.enabled(this, v));
                sw.setPadding(dp(12), 0, 0, 0);
                sw.setOnCheckedChangeListener((s, on) -> {
                    Prefs.setEnabled(this, v, on);
                    Scheduler.scheduleNext(this);
                    updateNext();
                });
                row.addView(sw);
            } else {
                TextView sp = tv("ezan yok", 12, SUB, false);
                sp.setPadding(dp(12), 0, 0, 0);
                row.addView(sp);
            }
            tc.addView(row);
            if (ezanli) {
                LinearLayout ar = hrow();
                ar.setPadding(0, 0, 0, dp(6));
                ar.addView(tv("Düzeltme:", 13, SUB, false));
                ar.addView(small("−", x -> changeAdj(v, -1)));
                ar.addView(tv((adj > 0 ? "+" : "") + adj + " dk", 13, SUB, false));
                ar.addView(small("+", x -> changeAdj(v, 1)));
                tc.addView(ar);
            }
        }
        root.addView(tc);

        // ---- Ses
        LinearLayout sc = card();
        sc.addView(tv("Ezan sesi", 17, GOLD, true));
        soundBlock(sc, "genel", "Tüm vakitler için ezan sesi", REQ_GENEL, 1);
        soundBlock(sc, "sabah", "Sabah ezanı için ayrı ses (isteğe bağlı)", REQ_SABAH, 0);

        TextView volTv = tv("Ezan ses seviyesi: %" + Prefs.volume(this), 15, TXT, false);
        volTv.setPadding(0, dp(10), 0, 0);
        sc.addView(volTv);
        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(Prefs.volume(this));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { volTv.setText("Ezan ses seviyesi: %" + Math.max(5, p)); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { Prefs.setVolume(MainActivity.this, Math.max(5, s.getProgress())); }
        });
        sc.addView(sb);
        sc.addView(tv("Ezan, telefonun alarm ses kanalından çalar: telefon sessizde veya titreşimdeyken de duyulur.", 12, SUB, false));
        root.addView(sc);

        // ---- Her koşulda çalması için
        LinearLayout kc = card();
        kc.addView(tv("Her koşulda çalması için", 17, GOLD, true));
        kc.addView(tv("Hepsi ✅ olunca ezan; güç tasarrufu, uyku modu ve kısıtlamalara rağmen vaktinde okunur.", 12, SUB, false));

        boolean notifOk = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
        checkRow(kc, "Bildirim izni", notifOk, "İzin ver", x -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        });

        checkRow(kc, "Tam zamanlı alarm izni", Scheduler.exactAllowed(this), "İzin ver", x -> {
            if (Build.VERSION.SDK_INT >= 31) open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName())));
        });

        PowerManager pm = getSystemService(PowerManager.class);
        boolean battOk = pm.isIgnoringBatteryOptimizations(getPackageName());
        checkRow(kc, "Pil optimizasyonu kapalı", battOk, "Kapat", x -> {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            if (!open(i)) open(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        });

        boolean bgOk = true;
        if (Build.VERSION.SDK_INT >= 28) {
            ActivityManager am = getSystemService(ActivityManager.class);
            bgOk = !am.isBackgroundRestricted();
        }
        checkRow(kc, "Arka plan kısıtlaması yok", bgOk, "Düzelt", x -> openAppDetails());

        LinearLayout mr = hrow();
        mr.setPadding(0, dp(8), 0, 0);
        TextView mt = tv("Üretici pil yöneticisi (" + Build.MANUFACTURER + ")", 15, TXT, false);
        mr.addView(mt, new LinearLayout.LayoutParams(0, -2, 1));
        mr.addView(button("Aç", x -> openAutoStart()));
        kc.addView(mr);
        kc.addView(tv(manufacturerTip(), 12, SUB, false));
        root.addView(kc);

        TextView foot = tv("Vakitler Diyanet yöntemiyle (imsak 18°, yatsı 17°, temkinli) telefonda hesaplanır; internet gerekmez. Diyanet takviminden 1 dakika fark görürseniz Düzeltme ile eşitleyebilirsiniz.", 12, SUB, false);
        foot.setPadding(0, dp(12), 0, dp(24));
        root.addView(foot);
    }

    private void soundBlock(LinearLayout parent, String key, String label, int req, int testVakit) {
        TextView l = tv(label, 15, TXT, false);
        l.setPadding(0, dp(8), 0, 0);
        parent.addView(l);
        File f = Prefs.soundFile(this, key);
        String name = Prefs.soundName(this, key);
        String status;
        if (Prefs.has(f)) status = "✅ " + (name != null ? name : "seçildi");
        else status = key.equals("genel") ? "⚠️ Seçilmedi – şimdilik telefonun alarm sesi çalar"
                : "Seçilmedi – sabah da genel ezan sesi çalar";
        parent.addView(tv(status, 13, Prefs.has(f) ? OK : (key.equals("genel") ? WARN : SUB), false));
        LinearLayout r = hrow();
        r.addView(button("Ses seç", x -> pick(req)));
        r.addView(button("▶ Dinle", x -> {
            Intent s = new Intent(this, EzanService.class).putExtra("vakit", testVakit).putExtra("test", true);
            startForegroundService(s);
        }));
        r.addView(button("■ Durdur", x -> startService(new Intent(this, EzanService.class).setAction(EzanService.ACTION_STOP))));
        if (key.equals("sabah") && Prefs.has(f)) {
            r.addView(button("Kaldır", x -> { f.delete(); build(); }));
        }
        parent.addView(r);
    }

    private void changeAdj(int v, int d) {
        int a = Math.max(-60, Math.min(60, Prefs.adj(this, v) + d));
        Prefs.setAdj(this, v, a);
        Scheduler.scheduleNext(this);
        build();
    }

    private void updateNext() {
        if (nextTv == null) return;
        Scheduler.Next n = Scheduler.findNext(this, System.currentTimeMillis());
        if (n == null) { nextTv.setText("Tüm ezanlar kapalı"); return; }
        long mins = (n.millis - System.currentTimeMillis()) / 60000 + 1;
        String kalan = mins >= 60 ? (mins / 60) + " sa " + (mins % 60) + " dk" : mins + " dk";
        String saat = DateTimeFormatter.ofPattern("HH:mm").withZone(PrayerTimes.ZONE).format(Instant.ofEpochMilli(n.millis));
        nextTv.setText("Sıradaki ezan: " + Prefs.VAKIT[n.vakit] + " • " + saat + "\n" + kalan + " sonra");
    }

    // ---------------------------------------------------------------- ses dosyası seçme
    private void pick(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        startActivityForResult(i, req);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final String key = req == REQ_SABAH ? "sabah" : "genel";
        final Uri uri = data.getData();
        final Context c = getApplicationContext();
        new Thread(() -> {
            boolean ok = copy(c, uri, key);
            runOnUiThread(() -> {
                Toast.makeText(this, ok ? "Ezan sesi kaydedildi" : "Dosya okunamadı", Toast.LENGTH_SHORT).show();
                build();
            });
        }).start();
    }

    private static boolean copy(Context c, Uri uri, String key) {
        File dst = Prefs.soundFile(c, key);
        File tmp = new File(dst.getPath() + ".tmp");
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[64 * 1024];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
        } catch (Exception e) {
            tmp.delete();
            return false;
        }
        if (!tmp.renameTo(dst)) return false;
        String name = null;
        try (Cursor cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) name = cur.getString(0);
        } catch (Exception ignored) { }
        Prefs.setSoundName(c, key, name);
        return true;
    }

    // ---------------------------------------------------------------- ayar ekranları
    private boolean open(Intent i) {
        try { startActivity(i); return true; } catch (Exception e) { return false; }
    }

    private void openAppDetails() {
        open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
    }

    private void openAutoStart() {
        String[][] comps = {
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                {"com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppListActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"},
                {"com.asus.mobilemanager", "com.asus.mobilemanager.MainActivity"},
        };
        String man = Build.MANUFACTURER.toLowerCase(Locale.ROOT);
        for (String[] c : comps) {
            boolean match = (man.contains("huawei") && c[0].contains("huawei"))
                    || (man.contains("honor") && c[0].contains("honor"))
                    || ((man.contains("xiaomi") || man.contains("redmi") || man.contains("poco")) && c[0].contains("miui"))
                    || ((man.contains("oppo") || man.contains("realme") || man.contains("oneplus")) && (c[0].contains("coloros") || c[0].contains("oplus")))
                    || (man.contains("vivo") && c[0].contains("vivo"))
                    || (man.contains("samsung") && c[0].contains("samsung"))
                    || (man.contains("asus") && c[0].contains("asus"));
            if (!match) continue;
            Intent i = new Intent().setComponent(new ComponentName(c[0], c[1]));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (open(i)) return;
        }
        openAppDetails();
    }

    private String manufacturerTip() {
        String m = Build.MANUFACTURER.toLowerCase(Locale.ROOT);
        if (m.contains("huawei") || m.contains("honor"))
            return "Huawei/Honor: Ayarlar › Pil › Uygulama başlatma › Ezan Vakti › \"Otomatik yönet\"i KAPATIN ve açılan üç anahtarı (otomatik başlatma, ikincil başlatma, arka planda çalışma) AÇIK bırakın.";
        if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco"))
            return "Xiaomi: Otomatik başlatmayı AÇIN; Uygulama bilgisi › Pil tasarrufu › \"Kısıtlama yok\" seçin.";
        if (m.contains("samsung"))
            return "Samsung: Uygulama bilgisi › Pil › \"Kısıtlanmamış\" seçin; Pil › Arka plan kullanım sınırları › \"Asla uyku moduna alınmayan uygulamalar\"a Ezan Vakti'ni ekleyin.";
        if (m.contains("oppo") || m.contains("realme") || m.contains("oneplus") || m.contains("vivo"))
            return "Otomatik başlatmayı AÇIN ve pil kullanımında \"Arka planda çalışmaya izin ver\" seçin.";
        return "Telefonunuzda \"otomatik başlatma\" veya \"uygulama başlatma\" ayarı varsa Ezan Vakti için açın.";
    }

    // ---------------------------------------------------------------- görsel yardımcılar
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static String hhmm(int m) {
        m = ((m % 1440) + 1440) % 1440;
        return String.format(Locale.US, "%02d:%02d", m / 60, m % 60);
    }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(16));
        c.setBackground(g);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout hrow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        GradientDrawable g = new GradientDrawable();
        g.setColor(BTN);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        b.setMinHeight(dp(40));
        b.setMinimumHeight(dp(40));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), dp(8), dp(4));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    private Button small(String s, View.OnClickListener l) {
        Button b = button(s, l);
        b.setMinWidth(dp(44));
        b.setMinimumWidth(dp(44));
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) b.getLayoutParams();
        lp.setMargins(dp(8), dp(2), dp(8), dp(2));
        return b;
    }

    private void checkRow(LinearLayout parent, String label, boolean ok, String btn, View.OnClickListener l) {
        LinearLayout r = hrow();
        r.setPadding(0, dp(6), 0, 0);
        TextView t = tv((ok ? "✅ " : "⚠️ ") + label, 15, ok ? OK : WARN, false);
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        if (!ok) r.addView(button(btn, l));
        parent.addView(r);
    }
}
