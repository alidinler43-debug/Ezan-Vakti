package com.alidinler.ezanvakti;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;

/** Ezan alarmı geldiğinde ezanı başlatır; telefon açılınca / saat değişince alarmı yeniden kurar. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String a = intent.getAction();
        if (Scheduler.ACTION_EZAN.equals(a)) {
            int v = intent.getIntExtra("vakit", 1);
            long t = intent.getLongExtra("time", System.currentTimeMillis());
            long now = System.currentTimeMillis();
            // Önce bir sonrakini kur, sonra çal
            Scheduler.scheduleNextAfter(c, Math.max(now, t) + 1000);
            if (now - t > 15 * 60 * 1000L) return; // çok gecikmiş bir alarmı çalma
            Intent s = new Intent(c, EzanService.class).putExtra("vakit", v);
            try {
                c.startForegroundService(s);
            } catch (Exception e) {
                fallbackNotify(c, v);
            }
        } else {
            Scheduler.scheduleNext(c);
        }
    }

    /** Sistem ezan servisini başlatmayı reddederse en azından alarm sesli bildirim. */
    static void fallbackNotify(Context c, int v) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel("ezan_yedek", "Ezan (yedek uyarı)",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
        ch.setBypassDnd(true);
        nm.createNotificationChannel(ch);
        Notification n = new Notification.Builder(c, "ezan_yedek")
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(Prefs.VAKIT[v] + " ezanı vakti")
                .setContentText("Ankara")
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .build();
        try { nm.notify(2, n); } catch (Exception ignored) { }
    }
}
