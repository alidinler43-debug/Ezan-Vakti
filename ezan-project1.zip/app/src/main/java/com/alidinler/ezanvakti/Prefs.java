package com.alidinler.ezanvakti;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Ayarlar ve ezan ses dosyaları. Telefon yeniden açılıp kilidi açılmadan
 *  önce de okunabilsin diye "cihaz korumalı" depolamada tutulur. */
public final class Prefs {
    public static final String[] VAKIT = {"Sabah", "Öğle", "İkindi", "Akşam", "Yatsı"};
    // Ezan vakit sırası -> PrayerTimes dizisindeki yeri (güneş atlanır)
    public static final int[] TIME_INDEX = {0, 2, 3, 4, 5};

    static Context dp(Context c) { return c.createDeviceProtectedStorageContext(); }

    static SharedPreferences sp(Context c) {
        return dp(c).getSharedPreferences("ezan", Context.MODE_PRIVATE);
    }

    public static boolean enabled(Context c, int v) { return sp(c).getBoolean("on_" + v, true); }
    public static void setEnabled(Context c, int v, boolean b) { sp(c).edit().putBoolean("on_" + v, b).apply(); }

    public static int adj(Context c, int v) { return sp(c).getInt("adj_" + v, 0); }
    public static void setAdj(Context c, int v, int m) { sp(c).edit().putInt("adj_" + v, m).apply(); }

    public static int volume(Context c) { return sp(c).getInt("volume", 100); }
    public static void setVolume(Context c, int v) { sp(c).edit().putInt("volume", v).apply(); }

    // ---- 4 ezan sesi yuvası (1, 2, 3, 4)
    public static final int SLOTS = 4;

    public static String soundName(Context c, int slot) { return sp(c).getString("name_ses" + slot, null); }
    public static void setSoundName(Context c, int slot, String n) { sp(c).edit().putString("name_ses" + slot, n).apply(); }

    public static File soundFile(Context c, int slot) {
        return new File(dp(c).getFilesDir(), "ezan_ses" + slot);
    }

    static boolean has(File f) { return f.exists() && f.length() > 0; }

    /** Bu vakit için seçilen ses yuvası (1-3); varsayılan 1. */
    public static int slotForVakit(Context c, int v) {
        int s = sp(c).getInt("slot_" + v, 1);
        return (s < 1 || s > SLOTS) ? 1 : s;
    }
    public static void setSlotForVakit(Context c, int v, int slot) { sp(c).edit().putInt("slot_" + v, slot).apply(); }

    // ---- Uygulamayla gelen hazır ezan sesleri
    public static final String[] HAZIR = {"Türkiye ezanı 1", "Türkiye ezanı 2", "Mekke ezanı (Ali Mulla)", "Ürdün – Kürdi makamı"};

    public static boolean customSet(Context c, int slot) { return has(soundFile(c, slot)); }

    static File builtInFile(Context c, int slot) { return new File(dp(c).getFilesDir(), "hazir_ses" + slot); }

    /** Hazır ses uygulamanın içinde var mı? */
    public static boolean builtInAvailable(Context c, int slot) {
        if (has(builtInFile(c, slot))) return true;
        try (InputStream in = c.getAssets().open("ezan" + slot + ".mp3")) {
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Hazır sesi (bir kez) uygulama içinden dosyaya çıkarır. */
    public static File ensureBuiltIn(Context c, int slot) {
        File h = builtInFile(c, slot);
        if (has(h)) return h;
        File tmp = new File(h.getPath() + ".tmp");
        try (InputStream in = c.getAssets().open("ezan" + slot + ".mp3");
             OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[64 * 1024];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
        } catch (Exception e) {
            tmp.delete();
            return null;
        }
        h.delete();
        return tmp.renameTo(h) && has(h) ? h : null;
    }

    public static void ensureAllBuiltIn(Context c) {
        for (int i = 1; i <= SLOTS; i++) ensureBuiltIn(c, i);
    }

    /** Yuvanın sesi: önce sizin seçtiğiniz, yoksa hazır ses; o da yoksa başka bir yuva; hiçbiri yoksa null (alarm sesi). */
    public static File fileForSlot(Context c, int slot) {
        File f = soundFile(c, slot);
        if (has(f)) return f;
        File h = ensureBuiltIn(c, slot);
        if (h != null) return h;
        for (int i = 1; i <= SLOTS; i++) {
            File o = soundFile(c, i);
            if (has(o)) return o;
            File oh = ensureBuiltIn(c, i);
            if (oh != null) return oh;
        }
        return null;
    }

    public static File fileForVakit(Context c, int v) { return fileForSlot(c, slotForVakit(c, v)); }
}
