package com.alidinler.ezanvakti;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

/**
 * Uygulamayı sürekli açık tutan sessiz ön plan hizmeti.
 * Vivo, Xiaomi, Oppo gibi telefonların pil yöneticisi arka plandaki uygulamaları
 * kapatıp alarmlarını engelleyebiliyor; ön planda çalışan bir hizmet kapatılmaz.
 */
public class BekciService extends Service {
    private static final String CH = "ezan_bekci";
    private static final int ID = 3;

    public static void start(Context c) {
        try {
            c.startForegroundService(new Intent(c, BekciService.class));
        } catch (Exception ignored) { }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Scheduler.scheduleNext(this);
        try {
            Notification n = build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(ID, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private Notification build() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CH, "Ezan bekleniyor", NotificationManager.IMPORTANCE_LOW);
        ch.setSound(null, null);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);

        String text = "Tüm ezanlar kapalı";
        Scheduler.Next nx = Scheduler.findNext(this, System.currentTimeMillis());
        if (nx != null) {
            String saat = DateTimeFormatter.ofPattern("HH:mm").withZone(PrayerTimes.ZONE)
                    .format(Instant.ofEpochMilli(nx.millis));
            text = "Sıradaki ezan: " + Prefs.VAKIT[nx.vakit] + " • " + saat;
        }
        PendingIntent open = PendingIntent.getActivity(this, 301, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Ezan Vakti açık")
                .setContentText(text)
                .setOngoing(true)
                .setShowWhen(false)
                .setContentIntent(open)
                .build();
    }
}
